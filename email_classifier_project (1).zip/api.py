from fastapi import APIRouter
from pydantic import BaseModel
from utils import mask_pii, unmask_pii
from models import predict_category

router = APIRouter()

class EmailRequest(BaseModel):
    email: str

@router.post("/")
def classify_email(request: EmailRequest):
    original_email = request.email
    masked_email, entities = mask_pii(original_email)
    category = predict_category(masked_email)
    demasked_email = unmask_pii(masked_email, entities)
    
    return {
        "input_email_body": original_email,
        "list_of_masked_entities": entities,
        "masked_email": masked_email,
        "category_of_the_email": category
    }