# Email Classification API

## Setup Instructions

1. Create a virtual environment:
```
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
```

2. Install dependencies:
```
pip install -r requirements.txt
```

3. Train the model:
```
python models.py
```

4. Run the API:
```
uvicorn app:app --reload
```

### Test the API

Send a POST request to:
```
http://127.0.0.1:8000/
```

With JSON body:
```json
{
  "email": "Hi, I am John Doe, my email is johndoe@example.com."
}
```