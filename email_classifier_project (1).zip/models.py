import joblib
import os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

MODEL_PATH = "model.joblib"
VECTORIZER_PATH = "vectorizer.joblib"

def train_model():
    # Dummy dataset
    data = {
        "email": [
            "I need help with my billing",
            "There is a technical issue with my login",
            "How can I manage my account details?"
        ],
        "label": ["Billing Issue", "Technical Support", "Account Management"]
    }
    df = pd.DataFrame(data)
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(df["email"])
    y = df["label"]

    model = MultinomialNB()
    model.fit(X, y)

    joblib.dump(model, MODEL_PATH)
    joblib.dump(vectorizer, VECTORIZER_PATH)

def predict_category(text):
    model = joblib.load(MODEL_PATH)
    vectorizer = joblib.load(VECTORIZER_PATH)
    X = vectorizer.transform([text])
    return model.predict(X)[0]

if __name__ == "__main__":
    train_model()